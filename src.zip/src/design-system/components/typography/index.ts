// Typography components export file
export { default as Text } from './Text';