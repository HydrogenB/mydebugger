// Navigation components export file
// This file will export all navigation components

export { TabGroup, Tab, TabPanel } from './TabGroup';